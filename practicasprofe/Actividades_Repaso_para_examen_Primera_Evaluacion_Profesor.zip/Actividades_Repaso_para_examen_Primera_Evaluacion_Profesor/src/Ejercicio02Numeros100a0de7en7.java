
public class Ejercicio02Numeros100a0de7en7 {
/*
 * Escribir todos los números del 100 al 0 de 7 en 7.
 */
	public static void main(String[] args) {

		for (int i= 100; i >=0 ; i-=7)
			System.out.println("numero : " + i);

	}

}
